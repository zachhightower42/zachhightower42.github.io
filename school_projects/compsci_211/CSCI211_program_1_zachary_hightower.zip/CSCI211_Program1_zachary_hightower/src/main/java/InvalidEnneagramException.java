public class InvalidEnneagramException extends RuntimeException{
    public InvalidEnneagramException(String str) {
        super(str);
    }
}
