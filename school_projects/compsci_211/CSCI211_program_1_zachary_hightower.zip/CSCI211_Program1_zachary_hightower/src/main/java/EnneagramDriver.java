/**
 * Zachary Paul Hightower
 * CSCI 211
 * Section 2
 * Program 1
 * In keeping with the Honor Code of the University of Mississippi, I have neither given nor
 * received inappropriate assistance on this assignment.
 * Is this necessary? I didn't see it in the actual files provided or the .pdf
 * But someone else had it and I got paranoid about whether or not I'm actually supposed to
 * Have this kind of thing in here, because in Joey's class we were required to
 * And I think there was a stipulation about it not being graded if it didn't have this.
 * Anyway, if this isn't necessary or is in the wrong place, please disregard all of this
 * Thanks
 */



import java.io.FileNotFoundException;

public class EnneagramDriver {
    public static void main(String[] args) throws FileNotFoundException {
        int [] temp;
        Enneagram fall2023 = new Enneagram("RHETI_Data_three.csv");
//        Enneagram fall2023 = new Enneagram("RHETI_Data.csv");
        fall2023.processResults();
        System.out.println(fall2023.printResults(0, 2));
        System.out.println("Count traits\n"+fall2023.countTraits(2, 2));
        System.out.println("Personality type\n"+fall2023.personalityTypes(0, 2));
        System.out.println(fall2023.printResults(0, 2));
        System.out.println("Count Class");
        temp = fall2023.countClass(0, 2);
        for(int i = 1; i < temp.length; i++) {
            System.out.println(i + ": " + temp[i]);
        }
        System.out.println("Most common trait\n"+fall2023.mostCommonType(0, 2));

    }
}
