
public class InvalidTrieException extends RuntimeException{
    /**
     * Sets up this exception with an appropriate message.
     */
    public InvalidTrieException()
    {
        super("Invalid Trie Element");
    }

}
