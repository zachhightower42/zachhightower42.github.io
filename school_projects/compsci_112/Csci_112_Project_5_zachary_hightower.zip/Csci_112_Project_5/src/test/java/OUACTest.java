import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class OUACTest {
    @Test
    void testingConstructorNotNull() throws IOException {
        OUAC auction = new OUAC("");
        assertNotNull(auction);
    }
    @Test
    void testConstructorValue1() throws IOException {
        OUAC auction = new OUAC("big");
        assertEquals("big",auction.getAuctionDate());
    }
    @Test
    void testConstructorValue2() throws IOException {
        OUAC auction = new OUAC("");
        auction.addAuctionItem("",0);
        auction.addAuctionItem("",1);
        auction.addBidderOUAC(0,"","",20);
        auction.addBidderOUAC(1,"","",20);
        auction.getItem(0).calcHighestBidAmount();
        auction.getItem(1).calcHighestBidAmount();
        auction.calcTotalRaisedByAuction();
        assertEquals(40,auction.getAuctionTotalRaised());
    }

    @Test
    void setAuctionTotalRaised() throws IOException {
        OUAC auction = new OUAC("");
        auction.setAuctionTotalRaised(20);
        assertEquals(20,auction.getAuctionTotalRaised());
    }


    @Test
    void setAuctionDate() throws IOException {
        OUAC auction = new OUAC("2999");
        auction.setAuctionDate("1990");
        assertEquals("1990",auction.getAuctionDate());
    }
    @Test
    void setNumberOfBids() throws IOException {
        OUAC auction = new OUAC("");
        auction.addAuctionItem("",0);
        auction.addBidderOUAC(0,"","",20);
        auction.addBidderOUAC(0,"","",20);
       auction.setNumberOfBids();
        assertEquals(2,auction.getItem(0).getNumberOfBids());
    }
    @Test
    void awardOne() throws IOException {
        OUAC auction = new OUAC("");
        auction.addAuctionItem("",0);
        auction.addAuctionItem("",1);
        auction.addBidderOUAC(0,"","",20);
        auction.addBidderOUAC(1,"","",40);
        auction.getItem(0).calcHighestBidAmount();
        auction.getItem(1).calcHighestBidAmount();
        assertEquals(1,auction.awardOne());
    }

    @Test
    void awardTwo() throws IOException {
        OUAC auction = new OUAC("");
        auction.addAuctionItem("",0);
        auction.addAuctionItem("",1);
        auction.addBidderOUAC(0,"","",20);
        auction.addBidderOUAC(0,"","",20);
        auction.addBidderOUAC(1,"","",20);
        auction.addBidderOUAC(1,"","",20);
        auction.addBidderOUAC(1,"","",20);
        auction.addBidderOUAC(1,"","",20);
        auction.setNumberOfBids();
        assertEquals(1,auction.awardTwo());
    }

    @Test
    void awardThree() throws IOException {
        OUAC auction = new OUAC("");
        auction.addAuctionItem("",0);
        auction.addAuctionItem("",1);
        auction.addBidderOUAC(0,"","",20);
        auction.addBidderOUAC(0,"","",20);
        auction.addBidderOUAC(1,"","",20);
        auction.setNumberOfBids();
        assertEquals(1,auction.awardThree());
    }
}