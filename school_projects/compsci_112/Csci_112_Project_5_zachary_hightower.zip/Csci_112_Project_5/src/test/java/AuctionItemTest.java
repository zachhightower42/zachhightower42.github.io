import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class AuctionItemTest {
    @Test
    void testingConstructorNotNull() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        assertNotNull(auctionItem);
    }

    @Test
    void testConstructorValue1() throws IOException {
        AuctionItem auctionItem = new AuctionItem("bread", 0);
        assertEquals("bread",auctionItem.getItemDescription());
    }
    @Test
    void testConstructorValue2() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 2);
        assertEquals(2,auctionItem.getItemNumber());
    }
    @Test
    void testConstructorValue3() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.setTotalBid(100.2);
        assertEquals(100.2,auctionItem.getTotalBid());
    }
    @Test
    void testConstructorValue4() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.setNumberOfBids(15);
        assertEquals(15,auctionItem.getNumberOfBids());
    }
    @Test
    void testConstructorValue5() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.setHighestBidAmount(200.2);
        assertEquals(200.2,auctionItem.getHighestBidAmount());
    }
    @Test
    void testConstructorValue6() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.setItemAverageBid(66.33);
        assertEquals(66.33,auctionItem.getItemAverageBid());
    }

    @Test
    void setItemDescription() throws IOException {
        AuctionItem auctionItem = new AuctionItem("bob", 0);
        auctionItem.setItemDescription("jeff");
        assertEquals("jeff",auctionItem.getItemDescription());
    }

    @Test
    void setItemNumber() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 2);
        auctionItem.setItemNumber(3);
        assertEquals(3,auctionItem.getItemNumber());
    }

    @Test
    void getBidders() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        assertNotNull(auctionItem.getBidders());
    }

    @Test
    void getBiddersSize() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.addBidder("","",0);
        assertEquals(1,auctionItem.getBiddersSize());
    }


    @Test
    void addBidder() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.addBidder("","",0);
        assertNotNull(auctionItem.getBidder(0));
    }
    @Test
    void calcTotalBidAmountForAnItem() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.addBidder("","",20);
        auctionItem.addBidder("","",20);
        auctionItem.calcTotalBidAmountForAnItem();
        assertEquals(40,auctionItem.getTotalBid());
    }

    @Test
    void calcAverageBidForAnItem() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.addBidder("","",20);
        auctionItem.addBidder("","",20);
        auctionItem.calcTotalBidAmountForAnItem();
        auctionItem.calcAverageBidForAnItem();
        assertEquals(20,auctionItem.getItemAverageBid());
    }

    @Test
    void calcHighestBidAmount() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.addBidder("","",10);
        auctionItem.addBidder("","",20);
        auctionItem.calcHighestBidAmount();
        assertEquals(20,auctionItem.getHighestBidAmount());
    }

    @Test
    void sort() throws IOException {
        AuctionItem auctionItem = new AuctionItem("", 0);
        auctionItem.addBidder("","",10);
        auctionItem.addBidder("","",20);
        auctionItem.sort(auctionItem.getBidders(),0,auctionItem.getBidders().size()-1);
        assertEquals(20,auctionItem.getBidders().get(0).getBidderAmount());
    }
}