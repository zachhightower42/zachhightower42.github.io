import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BidderTest {
    @Test
    void testingConstructorNotNull() {
        Bidder bidder = new Bidder("", "", 0.0);
        assertNotNull(bidder);
    }

    @Test
    void testConstructorValue1() {
        Bidder bidder = new Bidder("bob", "", 0.0);
        assertEquals("bob", bidder.getBidderName());
    }

    @Test
    void testConstructorValue2() {
        Bidder bidder = new Bidder("", "here", 0.0);
        assertEquals("here", bidder.getBidderTown());
    }

    @Test
    void testConstructorValue3() {
        Bidder bidder = new Bidder("", "", 10.2);
        assertEquals(10.2, bidder.getBidderAmount());
    }

    @Test
    void setBidderName() {
    Bidder bidder = new Bidder("jeff","",0.0);
    bidder.setBidderName("jeff");
    assertEquals("jeff",bidder.getBidderName());
}
    @Test
    void setBidderTown() {
        Bidder bidder = new Bidder("","here",0.0);
        bidder.setBidderTown("there");
        assertEquals("there",bidder.getBidderTown());
    }
    @Test
    void setBidderAmount() {
        Bidder bidder = new Bidder("","",10.2);
        bidder.setBidderAmount(20.4);
        assertEquals(20.4,bidder.getBidderAmount());
    }
}