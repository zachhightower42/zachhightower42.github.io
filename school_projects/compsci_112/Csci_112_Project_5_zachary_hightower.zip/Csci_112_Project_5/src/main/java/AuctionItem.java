import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class AuctionItem {
    //attributes and filewriter and printer
    private String itemDescription;
    private int itemNumber;
    private ArrayList<Bidder> bidders = new ArrayList<>();
    private double totalBid;
    private int numberOfBids;
    private double highestBidAmount;
    private double itemAverageBid;
    private int highestBidderTracker;
    FileWriter file3 = new FileWriter("printout.txt", true);
    PrintWriter writer = new PrintWriter(file3);
    //non-empty constructor
    public AuctionItem(String itemDescription, int itemNumber) throws IOException {
        this.itemDescription = itemDescription;
        this.itemNumber = itemNumber;
        this.totalBid = totalBid;
        this.numberOfBids = bidders.size();
        this.highestBidAmount = highestBidAmount;
        this.itemAverageBid = itemAverageBid;
    }
    //setters and getters
    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public int getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(int itemNumber) {
        this.itemNumber = itemNumber;
    }

    public ArrayList<Bidder> getBidders() {
        return bidders;
    }

    public void setBidders(ArrayList<Bidder> bidders) {
        this.bidders = bidders;
    }

    public double getTotalBid() {
        return totalBid;
    }

    public void setTotalBid(double totalBid) {
        this.totalBid = totalBid;
    }

    public int getNumberOfBids() {
        return numberOfBids;
    }

    public void setNumberOfBids(int numberOfBids) {
        this.numberOfBids = numberOfBids;
    }
    public int getBiddersSize(){return bidders.size();}

    public double getHighestBidAmount() {
        return highestBidAmount;
    }

    public void setHighestBidAmount(double highestBidAmount) {
        this.highestBidAmount = highestBidAmount;
    }
    public double getItemAverageBid() {
        return itemAverageBid;
    }
    public void setItemAverageBid(double itemAverageBid) {
        this.itemAverageBid = itemAverageBid;
    }
    //toString
    @Override
    public String toString() {
        return "-----------\nAuctionItem "+itemNumber+"\n" +
                "Description='" + itemDescription + "\n" +
                "Total of Bids=" + totalBid +"\n"+
                "Number of Bids=" + (bidders.size())+"\n" +
                "AverageBid=" + itemAverageBid +"\n"+
                "Highest Bid As Follows" + bidders.get(highestBidderTracker)+"\n-----------";
    }
    //add for bidder
    public void addBidder(String bidderName, String bidderTown, double bidderAmount){
        bidders.add(new Bidder(bidderName,bidderTown,bidderAmount));
    }
   //get method for a single bidder
    public Bidder getBidder(int i){
        return bidders.get(i);
    }
    //close method for the writer
    public void close(){
        writer.close();
    }
    //calculation methods
    public void calcTotalBidAmountForAnItem(){
        double totalBidAmount = 0.0;
        for (int i = 0; i < bidders.size(); i++) {
            totalBidAmount+=bidders.get(i).getBidderAmount();
        }
        setTotalBid(totalBidAmount);
        totalBidAmount=0.0;
    }
    public void calcAverageBidForAnItem(){
        itemAverageBid=(totalBid/(bidders.size()));
    }
    public void calcHighestBidAmount(){
            double highestBidSoFar = 0;
            for (int i = 0; i < bidders.size(); i++){
                if (bidders.get(i).getBidderAmount()>highestBidSoFar){
                    highestBidSoFar=bidders.get(i).getBidderAmount();
                    highestBidderTracker=i;
                }
                else ;
            }
            setHighestBidAmount(highestBidSoFar);
        }
        //recursive sort
    public void sort(ArrayList<Bidder> arrayList, int min, int max){
        quickSort(arrayList,min,max);
    }
    public static void quickSort(ArrayList<Bidder> array, int min, int max){
        int pivot;
        if(min < max){
            pivot = partition(array, min, max);
            quickSort(array, min, (pivot-1));
            quickSort(array, (pivot + 1), max);
        }
    }

    public static int partition(ArrayList<Bidder> array, int min, int max){

        Bidder pivot = array.get(min);
        int left = min;
        int right =max;
        while(left < right){
            while(array.get(left).getBidderAmount() >= pivot.getBidderAmount() && left < right){
                left++;
            }
            while(array.get(right).getBidderAmount() < pivot.getBidderAmount()){
                right--;
            }
            if(left < right){
                swap(array, left, right);
            }
        }
        swap(array, min, right);

        return right;
    }

    public static void swap(ArrayList<Bidder> array, int left, int right){
        Bidder temp = array.get(left);
        array.set(left, array.get(right));
        array.set(right,temp);
    }
}
