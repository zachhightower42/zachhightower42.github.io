public class Bidder {
    private String bidderName;
    private String bidderTown;
    private double bidderAmount;
    //non-empty constructor
    public Bidder(String bidderName, String bidderTown, double bidderAmount) {
        this.bidderName = bidderName;
        this.bidderTown = bidderTown;
        this.bidderAmount = bidderAmount;
    }
    //getters and setters
    public String getBidderName() {
        return bidderName;
    }

    public void setBidderName(String bidderName) {
        this.bidderName = bidderName;
    }

    public String getBidderTown() {
        return bidderTown;
    }

    public void setBidderTown(String bidderTown) {
        this.bidderTown = bidderTown;
    }

    public double getBidderAmount() {
        return bidderAmount;
    }

    public void setBidderAmount(double bidderAmount) {
        this.bidderAmount = bidderAmount;
    }
    //toString
    @Override
    public String toString() {
        return "\n###\n" +
                "Name= '" + bidderName + "\n" +
                "Town= '" + bidderTown + "\n" +
                "Bid Amount= " + bidderAmount +"\n";
    }
}
