import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class OUAC {
    //attributes and file writer and printer
    private String auctionDate;
    private ArrayList<AuctionItem> auctionItems = new ArrayList<>();
    private double auctionTotalRaised;
    FileWriter file3 = new FileWriter("printout.txt", true);
    PrintWriter writer = new PrintWriter(file3);
    int awardOneNumber;
    int awardTwoNumber;
    int awardThreeNumber;
    //non-empty constructor
    public OUAC(String auctionDate) throws IOException {
        this.auctionDate = auctionDate;
        this.auctionTotalRaised = auctionTotalRaised;
    }
    //getters and setters

    public double getAuctionTotalRaised() {
        return auctionTotalRaised;
    }

    public void setAuctionTotalRaised(double auctionTotalRaised) {
        this.auctionTotalRaised = auctionTotalRaised;
    }

    public String getAuctionDate() {
        return auctionDate;
    }

    public void setAuctionDate(String auctionDate) {
        this.auctionDate = auctionDate;
    }
    public AuctionItem getItem(int i){
        return auctionItems.get(i);
    }
    //setter for the number of bids
    public void setNumberOfBids(){
        for (int i = 0; i < auctionItems.size(); i++) {
            auctionItems.get(i).setNumberOfBids(auctionItems.get(i).getBiddersSize());
        }
    }

    //add auction item and bidder
public void addAuctionItem(String itemDescription, int itemNumber) throws IOException {
    auctionItems.add(new AuctionItem(itemDescription,itemNumber));
}
public void addBidderOUAC(int i,String bidderName, String bidderTown, double bidderAmount){
        auctionItems.get(i).addBidder(bidderName,bidderTown,bidderAmount);
}
//calculator for the total raised by the auction
public void calcTotalRaisedByAuction(){
        auctionTotalRaised=0.0;
    for (int i = 0; i < auctionItems.size(); i++) {
    auctionTotalRaised+=auctionItems.get(i).getHighestBidAmount();
        }
    }
    //print method for everything
    public void printAll(){
        //calculations and sets before printing
        for (int i = 0; i < auctionItems.size(); i++) {
            auctionItems.get(i).calcTotalBidAmountForAnItem();
            auctionItems.get(i).calcAverageBidForAnItem();
            auctionItems.get(i).calcHighestBidAmount();
        }
        calcTotalRaisedByAuction();
        setNumberOfBids();
        //start of first print
        System.out.println("Welcome to the Big Auction!");
        System.out.println("Date of our glorious auction "+auctionDate);
        System.out.println("Amount Raised by the Big Auction $"+auctionTotalRaised);
        for (int i = 0; i < auctionItems.size(); i++) {
            System.out.print(auctionItems.get(i).toString());
            for (int j = 0; j < auctionItems.get(i).getNumberOfBids(); j++) {
                System.out.print(auctionItems.get(i).getBidder(j).toString());
            }
        }
        System.out.println("Thanks for attending the Big Auction!");
        //end of first print
        //sorting
        for (int i = 0; i < auctionItems.size(); i++) {
            auctionItems.get(i).sort(auctionItems.get(i).getBidders(),0,auctionItems.get(i).getBidders().size()-1);
        }
        //beginning of second print, and data writing
        System.out.println("DATA SORTED");
        writer.println("DATA SORTED");
        System.out.println("Welcome to the Big Auction!");
        writer.println("Welcome to the Big Auction!");
        System.out.println("Date of our glorious auction "+auctionDate);
        writer.println("Date of our glorious auction "+auctionDate);
        System.out.println("Amount Raised by the Big Auction $"+auctionTotalRaised);
        writer.println("Amount Raised by the Big Auction $"+auctionTotalRaised);
        for (int i = 0; i < auctionItems.size(); i++) {
            System.out.print(auctionItems.get(i).toString());
            writer.print(auctionItems.get(i).toString());
            System.out.println();
            writer.println();
            for (int j = 0; j < auctionItems.get(i).getNumberOfBids(); j++) {
                System.out.print(auctionItems.get(i).getBidder(j).toString());
                writer.print(auctionItems.get(i).getBidder(j).toString());
            }
        }
        //prizes
        System.out.print("\n~~~~\nWINNER of our first award for highest overall bid.\n");
        writer.print("\n~~~~\nWINNER of our first award for highest overall bid.\n");
        System.out.print(auctionItems.get(awardOne()).toString());
        writer.print(auctionItems.get(awardOne()).toString());
        System.out.print("\n~~~~\nWINNER of our second award for most number of bids.\n");
        writer.print("\n~~~~\nWINNER of our second award for most number of bids.\n");
        System.out.print(auctionItems.get(awardTwo()).toString());
        writer.print(auctionItems.get(awardTwo()).toString());
        System.out.print("\n~~~~\nWINNER of our third award for least number of bids, better luck next time!\n");
        writer.print("\n~~~~\nWINNER of our third award for least number of bids, better luck next time!\n");
        System.out.print(auctionItems.get(awardThree()).toString());
        writer.print(auctionItems.get(awardThree()).toString());
        System.out.println("Thanks for attending the Big Auction!");
        writer.println("Thanks for attending the Big Auction!");
        close();
        for (int i = 0; i < auctionItems.size(); i++){
            auctionItems.get(i).close();
        }
    }
    //close method
    public void close(){
        writer.close();
    }
    //getting the awards
    public int awardOne(){
        double highestBidSoFar = 0;
        for (int i = 0; i < auctionItems.size(); i++){
           if (auctionItems.get(i).getHighestBidAmount()>highestBidSoFar){
               awardOneNumber= i;
               highestBidSoFar=auctionItems.get(i).getHighestBidAmount();
           }
           else ;
        }
        return awardOneNumber;
    }
    public int awardTwo(){
        int highestNumOfBidsSoFar = 0;
        for (int i = 0; i < auctionItems.size(); i++){
            if (auctionItems.get(i).getNumberOfBids()>highestNumOfBidsSoFar){
                awardTwoNumber= i;
                highestNumOfBidsSoFar=auctionItems.get(i).getNumberOfBids();
            }
            else ;
        }
        return awardTwoNumber;
    }
    public int awardThree(){
        int lowestNumberOfBidsSoFar = auctionItems.get(awardTwoNumber).getNumberOfBids();
        for (int i = 0; i < auctionItems.size(); i++){
            if (auctionItems.get(i).getNumberOfBids()<lowestNumberOfBidsSoFar){
                awardThreeNumber= i;
                lowestNumberOfBidsSoFar=auctionItems.get(i).getNumberOfBids();
            }
            else ;
        }
        return awardThreeNumber;
    }
}

