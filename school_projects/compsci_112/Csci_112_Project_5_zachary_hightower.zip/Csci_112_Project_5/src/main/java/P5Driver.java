import java.io.*;
import java.util.Scanner;
/*
Name: Zachary Hightower
Current Date: 4/28/2023
Sources Consulted: consulted wS3 schools site for code examples, looked up
quick sort explanation on youtube to refresh on how to make that work, talked
over project with roommate Hudson, used instructor provided notes, and used
some modified code from my previous projects
By submitting this work, I attest that it is my original work and that I did
not violate the University of Mississippi academic policies set forth in the
M book.
*/
public class P5Driver {
    //start of the main method
    public static void main(String[] args) throws IOException {
        //setting the date of the auction
        OUAC bigAuction = new OUAC("2025");
        //reading through the auction items and passing the data
        File file = new File("src/main/AuctionItems.txt");
        Scanner scan = new Scanner(file);
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] itemsData = line.split(",");
            bigAuction.addAuctionItem(itemsData[0], Integer.parseInt(itemsData[1]));
        }
        scan.close();
        //reading through the bidders and passing the data
        File file2 = new File("src/main/Bidders.txt");
        Scanner scan2 = new Scanner(file2);
        while (scan2.hasNextLine()) {
            String line2 = scan2.nextLine();
            String[] biddersData = line2.split(",");
            bigAuction.addBidderOUAC((Integer.parseInt(biddersData[2])-1),biddersData[0],biddersData[1],Double.parseDouble(biddersData[3]));
        }
        scan2.close();
        //calling the print method from OUAC
        bigAuction.printAll();
    }
}
