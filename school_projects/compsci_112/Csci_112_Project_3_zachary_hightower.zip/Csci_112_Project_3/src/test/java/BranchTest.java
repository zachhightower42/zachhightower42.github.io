import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BranchTest {

    @Test
    void getBranchLocation() {
        Branch testBranch = new Branch("Here",0);
        assertEquals("Here", testBranch.getBranchLocation());
    }

    @Test
    void getYearOpened() {
        Branch testBranch = new Branch("",2000);
        assertEquals(2000, testBranch.getYearOpened());
    }

    @Test
    void setBranchLocation() {
        Branch testBranch = new Branch("Here",0);
        testBranch.setBranchLocation("Not-Here");
        assertEquals("Not-Here", testBranch.getBranchLocation());
    }

    @Test
    void setYearOpened() {
        Branch testBranch = new Branch("",2000);
        testBranch.setYearOpened(1000);
        assertEquals(1000, testBranch.getYearOpened());
    }
}