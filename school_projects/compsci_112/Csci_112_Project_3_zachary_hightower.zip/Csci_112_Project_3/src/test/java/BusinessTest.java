import static org.junit.jupiter.api.Assertions.*;

class BusinessTest {

    @org.junit.jupiter.api.Test
    void getBusinessName() {
        Business testBusiness = new Business("MaccyD's");
        assertEquals("MaccyD's", testBusiness.getBusinessName());
    }

    @org.junit.jupiter.api.Test
    void setBusinessName() {
        Business testBusiness = new Business("MaccyD's");
        testBusiness.setBusinessName("Hardee's");
        assertEquals("Hardee's", testBusiness.getBusinessName());
    }
}