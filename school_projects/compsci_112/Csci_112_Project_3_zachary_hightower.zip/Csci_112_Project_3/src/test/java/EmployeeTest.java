import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeTest {

    @Test
    void getEmployeeName() {
        Employee testEmployee = new Employee("Bob","",0);
        assertEquals("Bob", testEmployee.getEmployeeName());
    }

    @Test
    void getEmployeePosition() {
        Employee testEmployee = new Employee("","Here",0);
        assertEquals("Here", testEmployee.getEmployeePosition());
    }

    @Test
    void getEmployeeSalary() {
        Employee testEmployee = new Employee("","",100);
        assertEquals(100, testEmployee.getEmployeeSalary());
    }

    @Test
    void setEmployeeName() {
        Employee testEmployee = new Employee("Bob","",0);
        testEmployee.setEmployeeName("Jeff");
        assertEquals("Jeff", testEmployee.getEmployeeName());
    }

    @Test
    void setEmployeePosition() {
        Employee testEmployee = new Employee("","Here",0);
        testEmployee.setEmployeePosition("Not-Here");
        assertEquals("Not-Here", testEmployee.getEmployeePosition());
    }

    @Test
    void setEmployeeSalary() {
        Employee testEmployee = new Employee("","",100);
        testEmployee.setEmployeeSalary(50);
        assertEquals(50, testEmployee.getEmployeeSalary());
    }
}