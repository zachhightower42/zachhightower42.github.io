import java.util.ArrayList;
import java.util.Scanner;
public class Branch {
    //attributes
    private String branchLocation;
    private int yearOpened;
    private ArrayList<Employee> employees = new ArrayList<>();
    //constructor
    public Branch(String branchLocation, int yearOpened) {
        this.branchLocation = branchLocation;
        this.yearOpened = yearOpened;
    }
//getters
    public String getBranchLocation() {
        return branchLocation;
    }
    public int getYearOpened() {
        return yearOpened;
    }
//setters
    public void setBranchLocation(String branchLocation) {
        this.branchLocation = branchLocation;
    }
    public void setYearOpened(int yearOpened) {
        this.yearOpened = yearOpened;
    }
    //adder for an employee
    public void addEmployee(String employeeName, String employeePosition, int employeeSalary){
        employees.add(new Employee(employeeName, employeePosition,employeeSalary));
    }
    //toString for printing branches
    public String toString(){
        String s = "Our branch in "+branchLocation+" has been providing quality service since "+yearOpened+"!\n"+
                "A list of our fine employees at this branch, their positions, and their salaries.\n";
        return s;
    }
    //print method for all employees within the branch
    public void printEmployees(){
        for (int i = 0; i < employees.size(); i++) {
            System.out.println(i+".| Name: "+employees.get(i).getEmployeeName()+ "|Position: "+employees.get(i).getEmployeePosition()+" |Salary: "+employees.get(i).getEmployeeSalary());
        }
    }
    //print method for a single employee in the branch
    public void printOneEmployee(int selected){
        System.out.println("Name: "+employees.get(selected).getEmployeeName()+ "|Position: "+employees.get(selected).getEmployeePosition()+" |Salary: "+employees.get(selected).getEmployeeSalary());
    }
    //editing an employee inside the branch
    public void editEmployee(){
        boolean exit = false;
        boolean exit2 = false;
        Scanner keyboard2 = new Scanner(System.in);
        System.out.println("Would you like to audit an employee in this branch?");
        System.out.println("Please type Y or N");
        String input;
        input = keyboard2.nextLine();
        if (input.equals("Y")){
            while (exit == false){
                System.out.println("Employees in this branch:");
                    printEmployees();
                System.out.println("Which employee would you like to audit?");
                System.out.println("Enter the number of the employee to select, or press N to quit out");
                String inputSelection;
                inputSelection = keyboard2.nextLine();
                if (inputSelection.equals("N")){
                    exit = true;
                    exit2=true;
                }
                else {
                    while (exit2 == false){
                        employees.get(Integer.parseInt(inputSelection));
                        printOneEmployee(Integer.parseInt(inputSelection));
                        System.out.println("What would you like to audit?\n"+
                                "1| Employee's name\n"+
                                "2| Employee's position in the company\n"+
                                "3| Employee's salary (you monster)\n"+
                                "4| Remove the employee from the business (also increases CEO pay)\n"+
                                "Enter the number next to the option or enter N to quit out\n");
                        String option;
                        option = keyboard2.nextLine();
                        if (option.equals("N")){
                            exit2 = true;
                        }
                        else {
                            int optionParse = Integer.parseInt(option);
                            if (optionParse == 1){
                                System.out.println("What should this employee's new name be?");
                                String newName;
                                newName = keyboard2.nextLine();
                                employees.get(Integer.parseInt(inputSelection)).setEmployeeName(newName);
                                System.out.println("The employee's new name is -"+employees.get(Integer.parseInt(inputSelection)).getEmployeeName());
                            }
                            else if (optionParse ==2){
                                System.out.println("What should this employee's position be?");
                                String newPosition;
                                newPosition = keyboard2.nextLine();
                                employees.get(Integer.parseInt(inputSelection)).setEmployeePosition(newPosition);
                                System.out.println("This employee's position is now -"+employees.get(Integer.parseInt(inputSelection)).getEmployeePosition());
                            }
                            else if (optionParse == 3){
                                System.out.println("What should this employee's new salary be?");
                                String newSalary;
                                newSalary = keyboard2.nextLine();
                                employees.get(Integer.parseInt(inputSelection)).setEmployeeSalary(Integer.parseInt(newSalary));
                                System.out.println("This employee's new salary is -"+employees.get(Integer.parseInt(inputSelection)).getEmployeeSalary());
                            }
                            else if (optionParse == 4){
                                System.out.println("Deploying employee severance package...");
                                employees.remove(Integer.parseInt(inputSelection));
                                System.out.println("The selected employee is no longer employed. -");
                                exit2=true;
                            }
                            }
                        }
                    }
                }

            }
        }

    }