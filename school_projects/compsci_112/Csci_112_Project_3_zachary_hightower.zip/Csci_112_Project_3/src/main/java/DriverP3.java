import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class DriverP3 {
    /*
   Name: Zachary Hightower
   Current Date: 3/23/2023
   Sources Consulted: looked up loop examples on WS3 schools, consulted with classmates,
   consulted with classmate Hudson in particular, as he is my roommate
   consulted course notes, and looked at some code from my previous projects and labs
   By submitting this work, I attest that it is my original work and that I did
   not violate the University of Mississippi academic policies set forth in the
   M book.
   */
    public static void main(String[] args) throws FileNotFoundException {
        //reading and passing the data to fill out employees and branches
        Business titanCommunication = new Business("Titan Communication");
        File file = new File("src/main/TitanCommunication.txt");
        Scanner scan = new Scanner(file);
        int index = -1;
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            String[] titanData = line.split(",");
            if (titanData.length == 2) {
                //filling out branches
                titanCommunication.addBranch(titanData[0], Integer.parseInt(titanData[1]));
                index++;}
             else if (titanData.length == 3) {
                 //filling out employees
                    titanCommunication.addEmployeeBusiness(index, titanData[0], titanData[1], Integer.parseInt(titanData[2]));
                }
            }
        scan.close();
        //end of read and pass
        //starts the auditor/editor
        titanCommunication.userBusinessEdit();
    }
}